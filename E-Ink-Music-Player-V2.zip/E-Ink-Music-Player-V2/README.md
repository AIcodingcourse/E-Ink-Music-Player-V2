# E-Ink Music Player V2

A modular ESP32 music player reference project with E-Ink display, microSD storage, physical controls, battery monitoring and I2S audio.

## Features
- ESP32-WROOM-32-class controller
- SPI E-Ink display
- microSD music storage
- MP3 playback through I2S
- Five physical buttons
- Battery voltage monitoring
- Low-power architecture
- PlatformIO firmware
- Modular C++ source
- Hardware and power documentation

## Reference pin map
| Function | GPIO |
|---|---:|
| SPI SCK | 18 |
| SPI MISO | 19 |
| SPI MOSI | 23 |
| SD CS | 5 |
| E-Ink CS | 15 |
| E-Ink DC | 4 |
| E-Ink RST | 16 |
| E-Ink BUSY | 17 |
| I2S BCLK | 14 |
| I2S LRCLK | 13 |
| I2S DOUT | 22 |
| Battery ADC | 34 |
| UP/DOWN/SELECT/BACK/PLAY | 32/33/25/26/27 |

These are a reference design and must be verified against the exact modules before production hardware.

## Music
Put MP3 files in `/music/` on a FAT32 microSD card.

## Build
```bash
cd firmware
pio run
pio run --target upload
pio device monitor
```

## Hardware status
Actual KiCad schematic/PCB files are intentionally not fabricated. The exact display, power circuit, amplifier and footprints must be verified before PCB design.

## License
MIT — see `LICENSE`.
