# Component Selection

ESP32-WROOM-32-class controller: SPI, I2S, ADC and sufficient GPIO.

GxEPD2-compatible SPI E-Ink: low-power persistent UI.

SPI microSD: removable music storage.

MAX98357A-class I2S amplifier: simple digital audio path.

Protected single-cell Li-ion/LiPo plus suitable charger/power path: portable power.

Five momentary buttons: simple navigation with internal pull-ups.

Exact part numbers and footprints must be frozen before PCB fabrication.
