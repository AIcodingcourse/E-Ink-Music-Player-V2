# Build Guide

1. Assemble only the verified reference modules.
2. Confirm all logic signals are 3.3 V compatible.
3. Format the microSD card as FAT32 and create `/music/`.
4. Build with PlatformIO.
5. Flash over USB.
6. Check serial output.
7. Test display, SD, buttons, ADC and finally audio.

Do not connect a raw Li-ion cell directly to a module unless its power input and charging architecture explicitly support it.
