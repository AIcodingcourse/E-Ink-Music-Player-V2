# Engineering Next Steps

1. Freeze exact display/controller.
2. Freeze ESP32 board/module.
3. Verify SD voltage and level shifting.
4. Verify I2S amplifier.
5. Finalize battery charger/power path.
6. Bench test the complete reference wiring.
7. Measure current in playback, idle and sleep.
8. Freeze electrical interfaces.
9. Create and review a real KiCad schematic.
10. Route the PCB and prototype it.
