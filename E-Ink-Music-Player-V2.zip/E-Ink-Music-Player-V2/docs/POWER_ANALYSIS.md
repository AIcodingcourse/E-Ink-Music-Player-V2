# Power Analysis

Highest normal loads are expected during simultaneous ESP32 processing, SD activity and audio amplification.

The E-Ink display is intended to minimize continuous display power because it retains an image between refreshes.

First-order battery estimate:

`runtime_hours ≈ battery_Wh × conversion_efficiency / average_load_W`

A 3.7 V, 2000 mAh cell is approximately 7.4 Wh nominal before losses.

This is an estimate, not a measured specification. Measure boot, idle, SD, E-Ink refresh, playback and sleep current on the real hardware.
