# Project Status

Software foundation: implemented.

Reference hardware architecture: documented.

Production hardware: not yet verified.

PCB: not created.

Battery runtime: not measured.

The exact E-Ink panel must be selected before the display driver and PCB are frozen.
