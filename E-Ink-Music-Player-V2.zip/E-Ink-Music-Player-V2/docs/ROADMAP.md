# Roadmap

## V2.0
Core ESP32, display, SD, audio, buttons and battery monitoring.

## V2.1
Track metadata, volume, previous/next, resume and better UI.

## V2.2
Folders, playlists, shuffle, repeat and favorites.

## V2.3
Deep sleep, wake sources, battery calibration and measured power data.

## V3.0
Bluetooth experiments, OTA and companion-device support.

## Hardware
Exact component freeze -> verified schematic -> PCB -> prototype -> measured validation.
