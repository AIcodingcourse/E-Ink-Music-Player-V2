# Wiring Reference

SPI: SCK 18, MISO 19, MOSI 23.

SD CS: GPIO5.

E-Ink: CS 15, DC 4, RST 16, BUSY 17.

I2S: BCLK 14, LRCLK 13, DOUT 22.

Buttons to GND with internal pull-ups: UP 32, DOWN 33, SELECT 25, BACK 26, PLAY 27.

Battery divider: BAT+ -> 100k -> GPIO34 -> 100k -> GND.

Verify exact module voltage requirements before assembly.
