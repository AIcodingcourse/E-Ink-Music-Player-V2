#pragma once
#include <Arduino.h>
class AudioPlayer {
public:
    AudioPlayer();
    ~AudioPlayer();
    bool begin();
    bool playFile(const char* path);
    void stop();
    void loop();
    bool isPlaying() const;
private:
    class AudioGeneratorMP3* decoder_;
    class AudioFileSourceSD* source_;
    class AudioOutputI2S* output_;
};
