#pragma once
#include <Arduino.h>
class BatteryMonitor {
public:
    void begin();
    float voltage();
    uint8_t percent();
};
