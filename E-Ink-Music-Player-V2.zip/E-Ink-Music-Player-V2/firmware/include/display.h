#pragma once
#include <Arduino.h>
class DisplayManager {
public:
    bool begin();
    void showStatus(const String& title, const String& detail);
    void showTrack(const String& name, bool playing);
};
