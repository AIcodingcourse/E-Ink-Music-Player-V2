#pragma once
#include <Arduino.h>
class MusicStorage {
public:
    bool begin();
    bool exists(const char* path) const;
    void printMusicFiles();
};
