#include "audio_player.h"
#include <SD.h>
#include "AudioFileSourceSD.h"
#include "AudioGeneratorMP3.h"
#include "AudioOutputI2S.h"

AudioPlayer::AudioPlayer() : decoder_(nullptr), source_(nullptr), output_(nullptr) {}
AudioPlayer::~AudioPlayer() { stop(); }

bool AudioPlayer::begin() {
    output_ = new AudioOutputI2S();
    if (!output_) return false;
    output_->SetPinout(14, 13, 22);
    output_->SetGain(0.35);
    return true;
}

bool AudioPlayer::playFile(const char* path) {
    stop();
    if (!SD.exists(path)) return false;
    source_ = new AudioFileSourceSD(path);
    decoder_ = new AudioGeneratorMP3();
    if (!source_ || !decoder_ || !decoder_->begin(source_, output_)) {
        stop();
        return false;
    }
    return true;
}

void AudioPlayer::stop() {
    if (decoder_) { if (decoder_->isRunning()) decoder_->stop(); delete decoder_; decoder_ = nullptr; }
    if (source_) { delete source_; source_ = nullptr; }
}

void AudioPlayer::loop() {
    if (decoder_ && !decoder_->loop()) stop();
}

bool AudioPlayer::isPlaying() const { return decoder_ && decoder_->isRunning(); }
