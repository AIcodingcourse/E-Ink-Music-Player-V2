#include "battery.h"
namespace {
constexpr uint8_t PIN = 34;
constexpr float ADC_MAX = 4095.0f;
constexpr float ADC_REF = 3.3f;
constexpr float DIVIDER = 2.0f;
}
void BatteryMonitor::begin() { pinMode(PIN, INPUT); analogReadResolution(12); }
float BatteryMonitor::voltage() { return (analogRead(PIN) / ADC_MAX) * ADC_REF * DIVIDER; }
uint8_t BatteryMonitor::percent() {
    float v = voltage();
    if (v <= 3.20f) return 0;
    if (v >= 4.20f) return 100;
    return (uint8_t)(((v - 3.20f) / 1.00f) * 100.0f);
}
