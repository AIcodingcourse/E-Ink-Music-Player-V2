#include "display.h"
#include <GxEPD2_BW.h>
#include <Fonts/FreeMonoBold9pt7b.h>

// Reference panel profile. Replace with the exact selected panel/controller.
GxEPD2_BW<GxEPD2_213_B74, GxEPD2_213_B74::HEIGHT> epd(
    GxEPD2_213_B74(15, 4, 16, 17));

bool DisplayManager::begin() {
    epd.init(115200);
    epd.setRotation(1);
    epd.setTextColor(GxEPD_BLACK);
    epd.setFont(&FreeMonoBold9pt7b);
    showStatus("E-Ink Music Player", "V2 ready");
    return true;
}

void DisplayManager::showStatus(const String& title, const String& detail) {
    epd.setFullWindow();
    epd.firstPage();
    do {
        epd.fillScreen(GxEPD_WHITE);
        epd.setCursor(4, 22); epd.print(title);
        epd.setCursor(4, 50); epd.print(detail);
    } while (epd.nextPage());
}

void DisplayManager::showTrack(const String& name, bool playing) {
    showStatus(playing ? "PLAYING" : "PAUSED", name);
}
