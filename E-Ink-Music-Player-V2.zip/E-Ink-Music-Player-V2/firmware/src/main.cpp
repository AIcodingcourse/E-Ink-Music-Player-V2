#include <Arduino.h>
#include "display.h"
#include "audio_player.h"
#include "battery.h"
#include "storage.h"

namespace {
constexpr uint8_t UP=32, DOWN=33, SELECT=25, BACK=26, PLAY=27;
constexpr uint32_t DEBOUNCE=35;
struct Button { uint8_t pin; bool last=HIGH; bool stable=HIGH; uint32_t changed=0; };
Button buttons[]={{UP},{DOWN},{SELECT},{BACK},{PLAY}};
DisplayManager display;
AudioPlayer audio;
BatteryMonitor battery;
MusicStorage storage;

bool pressed(Button& b) {
    bool r=digitalRead(b.pin);
    if(r!=b.last){b.changed=millis();b.last=r;}
    if(millis()-b.changed>DEBOUNCE && r!=b.stable){b.stable=r;return r==LOW;}
    return false;
}
}

void setup() {
    Serial.begin(115200);
    for(auto& b:buttons) pinMode(b.pin,INPUT_PULLUP);
    display.begin();
    battery.begin();
    if(!storage.begin()) display.showStatus("SD error","Check card"); else storage.printMusicFiles();
    audio.begin();
    display.showStatus("Ready",String(battery.percent())+"% battery");
}

void loop() {
    audio.loop();
    if(pressed(buttons[0])) Serial.println("UP");
    if(pressed(buttons[1])) Serial.println("DOWN");
    if(pressed(buttons[2])) Serial.println("SELECT");
    if(pressed(buttons[3])) { audio.stop(); display.showStatus("Stopped","BACK"); }
    if(pressed(buttons[4])) {
        if(audio.isPlaying()) { audio.stop(); display.showStatus("Paused","Playback stopped"); }
        else if(storage.exists("/music/song.mp3")) { audio.playFile("/music/song.mp3"); display.showTrack("song.mp3",true); }
        else display.showStatus("No test track","/music/song.mp3");
    }
    static uint32_t t=0;
    if(millis()-t>10000){t=millis();Serial.printf("Battery %.2fV %u%%\n",battery.voltage(),battery.percent());}
    delay(2);
}
