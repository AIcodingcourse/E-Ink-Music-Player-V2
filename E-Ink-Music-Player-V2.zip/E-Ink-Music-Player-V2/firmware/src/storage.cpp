#include "storage.h"
#include <SD.h>
namespace { constexpr uint8_t CS = 5; }
bool MusicStorage::begin() { return SD.begin(CS); }
bool MusicStorage::exists(const char* path) const { return SD.exists(path); }
void MusicStorage::printMusicFiles() {
    File root = SD.open("/music");
    if (!root || !root.isDirectory()) { Serial.println("/music not found"); return; }
    File f = root.openNextFile();
    while (f) { if (!f.isDirectory()) Serial.printf("Music: %s (%u bytes)\n", f.name(), (unsigned)f.size()); f.close(); f = root.openNextFile(); }
    root.close();
}
