# Firmware Test Plan

Hardware-independent targets: battery mapping, button debounce, path handling and playlist parsing.

Hardware integration targets: SD detection, E-Ink initialization, ADC measurement, I2S output, MP3 playback, stop/restart and sleep/wake.
