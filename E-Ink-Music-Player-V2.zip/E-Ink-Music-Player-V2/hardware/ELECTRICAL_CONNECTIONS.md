# Electrical Connections

Use a common ground. Shared SPI devices require independent chip-select lines. E-Ink and SD logic should be 3.3 V compatible. I2S connects ESP32 to the selected DAC/amplifier. Battery voltage reaches GPIO34 only through the resistor divider.
