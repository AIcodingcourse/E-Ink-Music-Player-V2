# Mechanical Connections

Place the E-Ink panel at the front, buttons around the display, ESP32/SD/audio electronics behind it, and the battery in a mechanically protected compartment. Leave access for USB and SD. Keep the speaker acoustically unobstructed.
