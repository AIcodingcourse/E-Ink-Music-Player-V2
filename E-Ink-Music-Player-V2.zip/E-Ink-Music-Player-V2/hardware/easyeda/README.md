# EasyEDA

No source PCB is included yet. The verified schematic/netlist should be frozen first; EasyEDA can then be used as an alternative PCB workflow.
