# KiCad

No fabricated `.kicad_sch` or `.kicad_pcb` files are included. They will only be created after the exact electrical design, components and footprints are verified. This prevents a fake schematic/PCB from being mistaken for a buildable design.
