# Images

Store verified project photographs, renders, UI screenshots and wiring diagrams here.
